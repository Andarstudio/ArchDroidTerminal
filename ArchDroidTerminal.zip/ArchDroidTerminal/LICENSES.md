# Licenses and attribution

ArchDroid Terminal's own source code: choose and add your own license file before distributing.

| Component | License | Notes |
|---|---|---|
| Termux `terminal-emulator`, `terminal-view` v0.118.0 | Apache-2.0 | Terminal emulation, PTY JNI. https://github.com/termux/termux-app |
| proot (built by Termux) | GPL-2.0-or-later | Bundled as `libproot.so` by `scripts/fetch-proot.ps1`. Source: https://github.com/termux/proot . If you redistribute the APK you must offer this source. |
| libtalloc | LGPL-3.0-or-later | Bundled as `libtalloc.so`. Dynamically linked. |
| Arch Linux ARM root filesystem | Per-package licenses | Downloaded at runtime from https://os.archlinuxarm.org |
| AndroidX, Jetpack Compose, Navigation, DataStore | Apache-2.0 | |
| Kotlin coroutines | Apache-2.0 | |
| OkHttp 4.12.0 | Apache-2.0 | |
| Apache Commons Compress 1.26.2 | Apache-2.0 | |

"Arch Linux" is a trademark of its respective owners; this project is not affiliated with Arch Linux or Arch Linux ARM.
