# Test status (honest)

Environment where this code was written: Linux sandbox with JDK 21 only. No Android SDK, no Gradle, no network, no device.

| Item | Status |
|---|---|
| Project compiles | **NOT RUN** |
| Unit tests (`PureLogicTest`: md5 parsing, pacman.conf patch, tar path traversal, path normalisation, byte formatting) | **written, NOT RUN** |
| APK builds / installs / launches | **NOT RUN** (no APK exists) |
| Terminal rendering, input, Ctrl+C/D, selection, copy/paste | **NOT RUN** |
| proot starts and bash runs in the rootfs | **NOT RUN** |
| Download resume, checksum verification, extraction | **NOT RUN** |
| `pacman -Syu`, `-S`, `-R`, persistence across restarts | **NOT RUN** |
| Settings persistence, reset/repair confirmations | **NOT RUN** |

Checked by research only: the Arch Linux ARM generic aarch64 tarball URL and the `pacman-key --init` / `--populate archlinuxarm` / `pacman -Syu`
bootstrap sequence match community and official-style install guides; the project's own `.md5`/`.sig` file names were not fetched here.

## Manual test checklist (on a real ARM64 phone)
1. Install APK, launch, complete setup; confirm it reaches the terminal only after the final verification step.
2. `uname -m` -> aarch64; `cat /etc/os-release`; `cd /home/user && pwd`.
3. `echo hi | grep h > /tmp/x; cat /tmp/x`; `sleep 100` then Ctrl+C; `cat` then Ctrl+D.
4. `pacman -Syu`, `pacman -Ss git`, `pacman -S git`, `git --version`, `pacman -R git`.
5. Kill the app from recents, reopen: installed packages and files still present; history via Up arrow.
6. Toggle airplane mode during download: error is shown, Retry resumes.
7. Rotate, background/foreground: sessions survive.
8. Settings changes persist after restart; Reset and Repair both ask for confirmation.
