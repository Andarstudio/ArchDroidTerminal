# Architecture

```
ui/            Compose screens (Setup, Terminal, Files, Settings, About), theme
terminal/      SessionManager (TerminalSession lifecycle), TerminalPalette (colours)
env/           EnvironmentManager (setup/repair/reset state machine), Downloader (resume + hashes),
               RootfsExtractor (tar.gz -> files, symlink-safe), ProotLauncher (command lines), PacmanConf
files/         VirtualFs (root-relative symlink resolution, safe delete)
data/          SettingsRepository (DataStore)
service/       SessionService (foreground service keeps the process alive)
```

## How a command runs
`TerminalSession` (Termux) forks a PTY child executing `libproot.so` from `nativeLibraryDir`:

`proot --kill-on-exit --link2symlink -0 -r <rootfs> -b /dev -b /proc -b /sys -b <fake /proc files> -w /root /usr/bin/env -i HOME=/root TERM=xterm-256color ... /bin/bash -l`

`env -i` keeps Android's `LD_LIBRARY_PATH` out of glibc programs. `-0` fakes uid 0 inside the guest only.
`PROOT_LOADER`, `PROOT_TMP_DIR`, `LD_LIBRARY_PATH` (with a `libtalloc.so.2` symlink) are set for proot itself.

## Key decisions
- **targetSdk 28**: Android 10+ forbids `execve` from app data for apps targeting 29+. proot ships as a native lib so it is
  executable regardless, but the guest's own binaries are launched by proot's loader. Targeting 28 follows Termux and keeps
  legacy shared-storage access simple. Trade-off: not Play-Store compatible, and Android shows a compatibility notice on new releases.
- **MD5 verification only**: Arch Linux ARM publishes `.md5` and a detached `.sig`. MD5 from the same origin only detects corruption,
  not a compromised server. Verify the `.sig` manually (gpg) if that matters to you. The SHA-256 is logged during setup.
- **pacman under proot**: `CheckSpace` commented out and `DisableSandbox` added (pacman 7 download sandbox needs Landlock/seccomp).
- **Symlink safety**: extraction refuses to write through symlinks and rejects `..`; deletion never follows symlinks.
- **Permissions**: INTERNET, ACCESS_NETWORK_STATE, FOREGROUND_SERVICE, and storage (only used for the optional /sdcard mount).
