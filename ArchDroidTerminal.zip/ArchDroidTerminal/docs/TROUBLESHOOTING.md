# Troubleshooting

**Gradle cannot resolve `com.github.termux.termux-app:terminal-view`.** JitPack may not have built that tag. Try
`https://jitpack.io/#termux/termux-app` to see build status or another tag. Fallback: copy the `terminal-emulator` and
`terminal-view` modules from the termux-app repository (Apache-2.0) into this project as Gradle modules and depend on them with
`implementation(project(":terminal-view"))`. The emulator module needs the NDK to build its JNI.

**Compile error in `SessionManager`/`TerminalScreen` about interface methods.** The Termux client interfaces differ slightly between
versions. Add/remove overrides to match the version you resolved.

**"Missing bundled proot components".** Run `scripts/fetch-proot.ps1`, then rebuild so the .so files are packaged.

**proot starts then exits / "CANNOT LINK EXECUTABLE ... library not found".** Termux's proot may depend on more libraries than
libtalloc (check the warning printed by the script). Bundle them as extra `lib*.so` files in `jniLibs/arm64-v8a`
and add matching soname symlinks in `ProotLauncher.prepareSupportFiles()`.

**Random crashes or "ptrace"/seccomp errors.** Keep Settings > "proot compatibility mode" on.

**pacman: "could not resolve host" / 404 errors.** Run `pacman -Syu` first. Check `/etc/resolv.conf`; Repair environment rewrites it.

**pacman: "unable to lock database".** After an interrupted operation use Settings > "Remove stale pacman lock" with no other session running pacman.

**pacman: signature errors.** Run Repair environment (re-initialises the keyring) and check the phone's date/time.

**Setup fails at "Initializing pacman keyring".** The log shows the real output. Entropy-starved gpg can be slow; retry resumes from the verified download but re-extracts.

**Not enough storage.** Setup needs about 4x the download size free (archive + extracted files + temp). Reset can also delete the archive.
