<#
.SYNOPSIS
  Downloads Termux's aarch64 build of proot (+ loader + libtalloc) and places them in
  app\src\main\jniLibs\arm64-v8a so the APK can execute them from nativeLibraryDir.

.NOTES
  * Run from PowerShell 5.1+ on Windows 11 (uses the built-in bsdtar `tar.exe`).
  * Downloads are verified against the SHA256 listed in the Termux repository index.
    Trust anchor = HTTPS to packages.termux.dev. For stronger assurance, verify the
    repository's signed Release/InRelease with Termux's GPG key yourself.
  * proot is GPL-2.0-or-later; libtalloc is LGPL-3.0-or-later (see LICENSES.md).
  * UNTESTED against the live repository at the time of writing: if a path below changed,
    the script stops with a clear message instead of guessing.
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$work = Join-Path $PSScriptRoot '_work'
$out  = Join-Path $root 'app\src\main\jniLibs\arm64-v8a'
$repo = 'https://packages.termux.dev/apt/termux-main'
New-Item -ItemType Directory -Force -Path $work, $out | Out-Null

Write-Host 'Downloading Termux package index (aarch64)...'
$indexPath = Join-Path $work 'Packages'
Invoke-WebRequest "$repo/dists/stable/main/binary-aarch64/Packages" -OutFile $indexPath
$blocks = (Get-Content $indexPath -Raw) -split "(\r?\n){2,}" | Where-Object { $_ -match '^Package: ' }

function Get-Pkg([string]$name) {
    $b = $blocks | Where-Object { $_ -match "(?m)^Package: $([regex]::Escape($name))\s*$" } | Select-Object -First 1
    if (-not $b) { throw "Package '$name' not found in the Termux index." }
    $f = [regex]::Match($b, '(?m)^Filename: (.+)$').Groups[1].Value.Trim()
    $s = [regex]::Match($b, '(?m)^SHA256: (.+)$').Groups[1].Value.Trim()
    $d = [regex]::Match($b, '(?m)^Depends: (.+)$').Groups[1].Value.Trim()
    if (-not $f -or -not $s) { throw "Index entry for '$name' is missing Filename/SHA256." }
    [pscustomobject]@{ Name = $name; File = $f; Sha = $s; Depends = $d }
}

function Expand-Pkg($pkg) {
    $deb = Join-Path $work ([IO.Path]::GetFileName($pkg.File))
    Write-Host "Downloading $($pkg.Name)..."
    Invoke-WebRequest "$repo/$($pkg.File)" -OutFile $deb
    $hash = (Get-FileHash $deb -Algorithm SHA256).Hash.ToLower()
    if ($hash -ne $pkg.Sha.ToLower()) { throw "SHA256 mismatch for $($pkg.Name): expected $($pkg.Sha), got $hash" }
    $dir = Join-Path $work $pkg.Name
    if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    tar -xf $deb -C $dir                      # .deb is an ar archive; bsdtar can read it
    $data = Get-ChildItem $dir -Filter 'data.tar.*' | Select-Object -First 1
    if (-not $data) { throw "No data.tar.* inside $($pkg.Name) .deb" }
    tar -xf $data.FullName -C $dir 2>$null    # symlink creation warnings on Windows are harmless
    return $dir
}

$proot  = Get-Pkg 'proot'
$talloc = Get-Pkg 'libtalloc'
Write-Host "proot depends on: $($proot.Depends)"
$extra = ($proot.Depends -split ',') | ForEach-Object { ($_ -split '[ (|]')[0].Trim() } | Where-Object { $_ -and $_ -notin @('libtalloc') }
if ($extra) { Write-Warning "proot has other dependencies this script does not bundle: $($extra -join ', '). If proot fails to start on the device, bundle them the same way (see docs/TROUBLESHOOTING.md)." }

$pd = Expand-Pkg $proot
$td = Expand-Pkg $talloc

$prootBin = Get-ChildItem $pd -Recurse -File -Filter 'proot' | Where-Object { $_.DirectoryName -match 'bin$' } | Select-Object -First 1
$loader   = Get-ChildItem $pd -Recurse -File -Filter 'loader' | Where-Object { $_.DirectoryName -match 'proot$' } | Select-Object -First 1
$lt       = Get-ChildItem $td -Recurse -File -Filter 'libtalloc.so*' | Sort-Object Length -Descending | Select-Object -First 1
if (-not $prootBin) { throw 'Could not find the proot binary in the package.' }
if (-not $loader)   { throw 'Could not find proot loader (libexec/proot/loader) in the package.' }
if (-not $lt)       { throw 'Could not find libtalloc in the package.' }

Copy-Item $prootBin.FullName (Join-Path $out 'libproot.so') -Force
Copy-Item $loader.FullName   (Join-Path $out 'libproot-loader.so') -Force
Copy-Item $lt.FullName       (Join-Path $out 'libtalloc.so') -Force
Write-Host "Done. Files in $out :"
Get-ChildItem $out | Format-Table Name, Length
Write-Host 'Now build the APK (see README.md).'
