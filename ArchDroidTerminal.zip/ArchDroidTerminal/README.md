# ArchDroid Terminal

Android app (Kotlin, Jetpack Compose) that gives you a real terminal running a genuine
**Arch Linux ARM (aarch64)** userspace without root, via **proot**. Terminal emulation and the PTY come
from Termux's `terminal-emulator`/`terminal-view` libraries. `pacman` is the real Arch Linux ARM pacman.

> **Status: source code only. Nothing in this project has been compiled, installed or run yet.**
> It was written without an Android SDK, Gradle, network access or a device. Expect to fix a few compile
> errors on the first build. See `docs/TESTING.md` for exactly what is and isn't verified.

## Requirements
- Windows 11, Android Studio (Koala or newer; bundled JDK 17+ is fine)
- Android SDK Platform 34 (Android Studio offers to install it)
- An ARM64 Android phone (Android 8.0+), roughly 4 GB free storage
- Internet for Gradle and for the first-launch rootfs download

## 1. Get proot (required, one time)
The app executes proot from its native library directory (the only reliable way on Android 10+).
Binaries are not included in this zip. In PowerShell, from the project folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\fetch-proot.ps1
```
This downloads Termux's aarch64 `proot`, its loader and `libtalloc` (checking the SHA256 from the Termux index)
and writes `libproot.so`, `libproot-loader.so`, `libtalloc.so` into `app\src\main\jniLibs\arm64-v8a`.
Without them the app starts but setup stops with "Missing bundled proot components".

## 2. Build
Android Studio: **File > Open** the folder, let Gradle sync, then **Run** on your phone (USB debugging on) or **Build > Build APK(s)**.

Command line (PowerShell). If `gradlew.bat` is missing, Android Studio creates it on sync, or run `gradle wrapper --gradle-version 8.9` once:
```powershell
.\gradlew.bat assembleDebug      # app\build\outputs\apk\debug\app-debug.apk
.\gradlew.bat assembleRelease    # signed with the debug key unless keystore.properties exists
.\gradlew.bat testDebugUnitTest  # JVM unit tests
```
Optional release signing: create `keystore.properties` in the project root with `storeFile`, `storePassword`, `keyAlias`, `keyPassword`.

## 3. Install
```powershell
adb devices
adb install -r app\build\outputs\apk\debug\app-debug.apk
```
(or just press Run in Android Studio).

## 4. First launch
Welcome screen > device checks (arm64, free space, network, download size read from the server) >
**Download and install**. The app downloads `ArchLinuxARM-aarch64-latest.tar.gz` from os.archlinuxarm.org,
verifies its MD5 against the published `.md5`, extracts it, configures DNS/pacman/bash, runs
`pacman-key --init` and `--populate archlinuxarm`, then checks `uname -m`, `/etc/os-release` and `pacman --version`.
Only then does it open the terminal. The download resumes after interruption; extraction restarts.

In the terminal, first run `pacman -Syu` (a fresh rootfs has stale databases), then e.g. `pacman -S git`.

## Features
Real PTY shell (bash in Arch via proot), multiple sessions, dark/light themes, font/cursor/scrollback settings,
extra-keys row (Esc, Tab, sticky Ctrl/Alt, ^C, ^D, arrows), copy/paste/selection (long-press), pinch to zoom,
persistent history (`~/.bash_history`), file browser (Linux and Android shared storage, clearly labelled),
repair and reset with confirmation, storage usage, foreground service so sessions survive backgrounding.

## Docs
`docs/ARCHITECTURE.md`, `docs/TROUBLESHOOTING.md`, `docs/TESTING.md`, `LICENSES.md`.


Note: the rootfs is downloaded from https://ca.us.mirror.archlinuxarm.org/os because the certificate of os.archlinuxarm.org does not match its hostname. Change `ArchArm.BASE_URL` in `env/EnvPaths.kt` to switch mirrors.
