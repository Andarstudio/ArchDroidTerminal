package dev.archdroid.terminal.env

import android.content.Context
import java.io.File

/** Where the Arch Linux ARM userspace comes from. Origin: https://archlinuxarm.org/platforms/armv8/generic */
object ArchArm {
    const val BASE_URL = "https://os.archlinuxarm.org/os"
    const val TARBALL = "ArchLinuxARM-aarch64-latest.tar.gz"
    const val TARBALL_URL = "$BASE_URL/$TARBALL"
    const val MD5_URL = "$TARBALL_URL.md5"
    /** Detached GPG signature. Not verified in-app (see docs); published so it can be checked manually. */
    const val SIG_URL = "$TARBALL_URL.sig"
}

/** All on-disk locations. Everything lives in the app-private files dir (no root, no extra permissions). */
class EnvPaths(context: Context) {
    val filesDir: File = context.filesDir
    val rootfs = File(filesDir, "rootfs")
    val rootfsTmp = File(filesDir, "rootfs.tmp")
    val downloads = File(filesDir, "downloads")
    val support = File(filesDir, "support")
    val prootTmp = File(filesDir, "proot-tmp")
    val marker = File(filesDir, "env.verified")

    val nativeDir = File(context.applicationInfo.nativeLibraryDir)
    val proot = File(nativeDir, "libproot.so")
    val prootLoader = File(nativeDir, "libproot-loader.so")
    val talloc = File(nativeDir, "libtalloc.so")

    val tarball = File(downloads, ArchArm.TARBALL)
    val tarballPart = File(downloads, ArchArm.TARBALL + ".part")
}
