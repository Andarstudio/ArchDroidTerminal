package dev.archdroid.terminal

import android.app.Application
import android.content.Context
import dev.archdroid.terminal.data.SettingsRepository
import dev.archdroid.terminal.env.EnvironmentManager
import dev.archdroid.terminal.terminal.SessionManager

/** Process-wide singletons. They outlive the Activity, so terminal sessions survive rotation/recreation. */
class ArchDroidApp : Application() {
    lateinit var settings: SettingsRepository
        private set
    lateinit var env: EnvironmentManager
        private set
    lateinit var sessions: SessionManager
        private set

    override fun onCreate() {
        super.onCreate()
        settings = SettingsRepository(this)
        env = EnvironmentManager(this, settings)
        sessions = SessionManager(this, env, settings)
    }
}

val Context.app: ArchDroidApp get() = applicationContext as ArchDroidApp
