package dev.archdroid.terminal.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import dev.archdroid.terminal.app
import dev.archdroid.terminal.env.EnvState

@Composable
fun AppRoot(dark: Boolean) {
    val env = LocalContext.current.app.env
    val state by env.state.collectAsStateWithLifecycle()
    when (state) {
        EnvState.Checking -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        EnvState.Ready -> MainNav(dark)
        else -> SetupScreen(state)
    }
}

@Composable
private fun MainNav(dark: Boolean) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "terminal") {
        composable("terminal") { TerminalScreen(dark, onFiles = { nav.navigate("files") }, onSettings = { nav.navigate("settings") }) }
        composable("files") { FilesScreen(onBack = { nav.popBackStack() }) }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }, onAbout = { nav.navigate("about") }) }
        composable("about") { AboutScreen(onBack = { nav.popBackStack() }) }
    }
}
