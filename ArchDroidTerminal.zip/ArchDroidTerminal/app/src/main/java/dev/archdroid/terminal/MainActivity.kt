package dev.archdroid.terminal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.archdroid.terminal.data.AppSettings
import dev.archdroid.terminal.data.ThemeMode
import dev.archdroid.terminal.ui.AppRoot
import dev.archdroid.terminal.ui.ArchDroidTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val s by app.settings.flow.collectAsStateWithLifecycle(AppSettings())
            val dark = when (s.theme) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
            }
            ArchDroidTheme(dark) {
                Surface { AppRoot(dark) }
            }
        }
    }
}
