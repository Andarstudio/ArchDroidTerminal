package dev.archdroid.terminal.env

/** Pure text transforms for guest config files (unit-tested). */
object PacmanConf {
    /**
     * proot has no real mount table, so CheckSpace fails ("could not determine filesystem mount points").
     * pacman >= 7 sandboxes downloads with Landlock/seccomp, which proot cannot provide; DisableSandbox
     * turns that off (older pacman only warns about the unknown directive). Idempotent.
     */
    fun patch(text: String): String {
        val lines = text.lines().toMutableList()
        for (i in lines.indices) if (lines[i].trim() == "CheckSpace") lines[i] = "#CheckSpace"
        if (lines.none { it.trim().startsWith("DisableSandbox") }) {
            val idx = lines.indexOfFirst { it.trim() == "[options]" }
            if (idx >= 0) lines.add(idx + 1, "DisableSandbox")
        }
        return lines.joinToString("\n")
    }
}

object GuestFiles {
    const val BASHRC_MARK = "# ArchDroid defaults"
    val BASHRC = """
$BASHRC_MARK
export HISTFILE=~/.bash_history HISTSIZE=50000 HISTFILESIZE=100000 HISTCONTROL=ignoreboth
shopt -s histappend checkwinsize
PROMPT_COMMAND='history -a'
alias ls='ls --color=auto'
alias grep='grep --color=auto'
alias ll='ls -lah'
PS1='\[\e[1;32m\]\u@archdroid\[\e[0m\]:\[\e[1;34m\]\w\[\e[0m\]\${'$'}'
if [ ! -e /var/lib/pacman/sync/core.db ]; then
  echo "Tip: sync the package databases first with: pacman -Syu"
fi
""".trimStart()
}
