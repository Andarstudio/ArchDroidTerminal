package dev.archdroid.terminal.env

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

class Downloader(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build(),
) {
    suspend fun fetchText(url: String, maxBytes: Long = 64 * 1024): String = withContext(Dispatchers.IO) {
        client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} for $url")
            val body = resp.body ?: throw IOException("Empty response for $url")
            val bytes = body.source().readByteArray(minOf(maxBytes, body.contentLength().takeIf { it > 0 } ?: maxBytes))
            String(bytes, Charsets.UTF_8)
        }
    }

    /** Returns the Content-Length from a HEAD request, or null if the server does not say. */
    suspend fun contentLength(url: String): Long? = withContext(Dispatchers.IO) {
        client.newCall(Request.Builder().url(url).head().build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} for $url")
            resp.header("Content-Length")?.toLongOrNull()
        }
    }

    /**
     * Downloads [url] into [dest], resuming a previous "[dest].part" with an HTTP Range request when
     * the server allows it. On success the .part file is atomically renamed to [dest].
     */
    suspend fun download(url: String, dest: File, onProgress: (done: Long, total: Long) -> Unit) =
        withContext(Dispatchers.IO) {
            dest.parentFile?.mkdirs()
            val part = File(dest.path + ".part")
            var existing = if (part.exists()) part.length() else 0L

            val builder = Request.Builder().url(url)
            if (existing > 0) builder.header("Range", "bytes=$existing-")
            client.newCall(builder.build()).execute().use { resp ->
                val append: Boolean
                val total: Long
                when (resp.code) {
                    206 -> {
                        append = true
                        // Content-Range: bytes start-end/total
                        total = resp.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                            ?: (existing + (resp.body?.contentLength() ?: -1))
                    }
                    200 -> {
                        append = false
                        existing = 0
                        total = resp.body?.contentLength() ?: -1
                    }
                    416 -> {
                        // Range not satisfiable: the .part is already complete or invalid. Start over.
                        part.delete()
                        throw IOException("Server rejected resume range; the partial file was discarded. Retry to download again.")
                    }
                    else -> throw IOException("HTTP ${resp.code} for $url")
                }
                val body = resp.body ?: throw IOException("Empty response")
                RandomAccessFile(part, "rw").use { raf ->
                    if (append) raf.seek(existing) else raf.setLength(0)
                    val buf = ByteArray(64 * 1024)
                    var done = existing
                    var lastReport = 0L
                    body.byteStream().use { input ->
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            raf.write(buf, 0, n)
                            done += n
                            val now = System.nanoTime()
                            if (now - lastReport > 200_000_000L) {
                                lastReport = now
                                onProgress(done, total)
                            }
                        }
                    }
                    onProgress(done, total)
                    if (total > 0 && done != total) {
                        throw IOException("Download ended early ($done of $total bytes). Retry to resume.")
                    }
                }
            }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw IOException("Could not move ${part.name} into place")
        }

    data class Digests(val md5: String, val sha256: String)

    /** Computes MD5 and SHA-256 in a single pass over the file. */
    suspend fun digests(file: File, onProgress: (done: Long, total: Long) -> Unit): Digests =
        withContext(Dispatchers.IO) {
            val md5 = MessageDigest.getInstance("MD5")
            val sha = MessageDigest.getInstance("SHA-256")
            val total = file.length()
            var done = 0L
            var last = 0L
            FileInputStream(file).use { input ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    coroutineContext.ensureActive()
                    val n = input.read(buf)
                    if (n < 0) break
                    md5.update(buf, 0, n)
                    sha.update(buf, 0, n)
                    done += n
                    val now = System.nanoTime()
                    if (now - last > 200_000_000L) { last = now; onProgress(done, total) }
                }
            }
            onProgress(total, total)
            Digests(md5.digest().toHex(), sha.digest().toHex())
        }

    companion object {
        private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }

        /** Parses "<md5>  <filename>" style checksum files. Returns null if no valid 32-hex digest is found. */
        fun parseMd5(text: String, fileName: String): String? {
            val lines = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
            val candidates = lines.filter { it.contains(fileName) }.ifEmpty { lines }
            for (line in candidates) {
                val token = line.split(Regex("\\s+")).firstOrNull()?.lowercase() ?: continue
                if (token.matches(Regex("[0-9a-f]{32}"))) return token
            }
            return null
        }
    }
}
