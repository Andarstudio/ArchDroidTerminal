package dev.archdroid.terminal.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Arch = Color(0xFF1793D1)

@Composable
fun ArchDroidTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(primary = Arch, background = Color(0xFF0F1115), surface = Color(0xFF151922))
    else lightColorScheme(primary = Color(0xFF0B6FA4), background = Color(0xFFFAFAFA), surface = Color(0xFFFFFFFF))
    MaterialTheme(colorScheme = scheme, content = content)
}
