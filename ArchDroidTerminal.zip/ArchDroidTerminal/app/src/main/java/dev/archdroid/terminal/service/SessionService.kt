package dev.archdroid.terminal.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/** Keeps the process (and therefore the shell sessions) alive while the app is in the background. */
class SessionService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("sessions", "Terminal sessions", NotificationManager.IMPORTANCE_LOW))
        }
        val n = Notification.Builder(this, "sessions")
            .setContentTitle("ArchDroid Terminal")
            .setContentText("Terminal sessions are running")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        return START_NOT_STICKY
    }
}
