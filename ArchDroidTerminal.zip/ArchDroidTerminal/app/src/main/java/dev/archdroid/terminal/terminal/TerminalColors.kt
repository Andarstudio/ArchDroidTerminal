package dev.archdroid.terminal.terminal

import com.termux.terminal.TerminalColors
import java.util.Properties

object TerminalPalette {
    private val dark = mapOf(
        "foreground" to "#C8D3F5", "background" to "#0F1115", "cursor" to "#1793D1",
        "color0" to "#1B1E28", "color1" to "#F7768E", "color2" to "#9ECE6A", "color3" to "#E0AF68",
        "color4" to "#7AA2F7", "color5" to "#BB9AF7", "color6" to "#7DCFFF", "color7" to "#A9B1D6",
        "color8" to "#414868", "color9" to "#FF899D", "color10" to "#9FE044", "color11" to "#FABA4A",
        "color12" to "#8DB0FF", "color13" to "#C7A9FF", "color14" to "#A4DAFF", "color15" to "#C0CAF5",
    )
    private val light = mapOf(
        "foreground" to "#2E3440", "background" to "#FAFAFA", "cursor" to "#0B6FA4",
        "color0" to "#2E3440", "color1" to "#B3261E", "color2" to "#2E7D32", "color3" to "#8A6D00",
        "color4" to "#1565C0", "color5" to "#7B1FA2", "color6" to "#00838F", "color7" to "#CFD8DC",
        "color8" to "#546E7A", "color9" to "#D32F2F", "color10" to "#388E3C", "color11" to "#A67C00",
        "color12" to "#1976D2", "color13" to "#8E24AA", "color14" to "#0097A7", "color15" to "#ECEFF1",
    )

    fun backgroundArgb(darkTheme: Boolean): Int = android.graphics.Color.parseColor((if (darkTheme) dark else light)["background"])

    /** Sets the global color scheme. Call SessionManager.applyColors() afterwards to refresh live sessions. */
    fun apply(darkTheme: Boolean) {
        val p = Properties()
        (if (darkTheme) dark else light).forEach { (k, v) -> p[k] = v }
        TerminalColors.COLOR_SCHEME.updateWith(p)
    }
}
