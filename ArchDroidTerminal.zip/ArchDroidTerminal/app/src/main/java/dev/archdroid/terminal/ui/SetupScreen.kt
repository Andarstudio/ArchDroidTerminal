package dev.archdroid.terminal.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.archdroid.terminal.app
import dev.archdroid.terminal.env.*

@Composable
fun SetupScreen(state: EnvState) {
    val env = LocalContext.current.app.env
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("ArchDroid Terminal", style = MaterialTheme.typography.headlineMedium)
        when (state) {
            is EnvState.NeedsSetup -> Welcome(env, state.note)
            is EnvState.SettingUp -> Progress(env, state)
            is EnvState.Failed -> Failure(env, state)
            else -> {}
        }
    }
}

@Composable
private fun Welcome(env: EnvironmentManager, note: String?) {
    var pf by remember { mutableStateOf<Preflight?>(null) }
    var nonce by remember { mutableIntStateOf(0) }
    LaunchedEffect(nonce) { pf = null; pf = env.preflight() }

    Text("A real Arch Linux ARM userspace, running without root through proot. Nothing is simulated: commands run in a genuine bash inside the downloaded root filesystem.")
    Text("What will happen", style = MaterialTheme.typography.titleMedium)
    Text("1. Download ${ArchArm.TARBALL} from os.archlinuxarm.org (the official Arch Linux ARM generic aarch64 root filesystem).\n" +
        "2. Verify it against the published MD5 checksum (and show its SHA-256).\n" +
        "3. Extract it into this app's private storage, configure DNS/pacman/bash, then run pacman-key --init and --populate archlinuxarm.\n" +
        "4. Verify that uname, pacman and /etc/os-release work before showing the terminal.")
    note?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

    val p = pf
    if (p == null) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Checking device…") }
    else {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Architecture: ${p.abis} ${if (p.arm64) "✓" else "✗"}")
                Text("Download size: ${p.downloadBytes?.let(::formatBytes) ?: "unknown"}${if (p.partialBytes > 0) " (${formatBytes(p.partialBytes)} already downloaded)" else ""}")
                Text("Free storage: ${formatBytes(p.freeBytes)} (need about ${formatBytes(p.requiredBytes)})")
                Text("Network: ${if (p.network) "connected" + if (p.metered) " (metered — consider Wi-Fi)" else "" else "offline"}")
            }
        }
        p.problems.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { env.startSetup() }, enabled = p.ok) { Text(if (p.partialBytes > 0) "Resume setup" else "Download and install") }
            OutlinedButton(onClick = { nonce++ }) { Text("Re-check") }
        }
    }
}

@Composable
private fun Progress(env: EnvironmentManager, state: EnvState.SettingUp) {
    val p = state.progress
    Text(if (state.repair) "Repairing environment" else "Setting up", style = MaterialTheme.typography.titleMedium)
    Text(p.step.label)
    if (p.fraction != null) LinearProgressIndicator(progress = { p.fraction }, modifier = Modifier.fillMaxWidth())
    else LinearProgressIndicator(Modifier.fillMaxWidth())
    Text(p.detail, maxLines = 2, fontSize = 12.sp)
    LogBox(p.log)
    OutlinedButton(onClick = { env.cancel() }) { Text("Cancel (progress is kept)") }
}

@Composable
private fun Failure(env: EnvironmentManager, state: EnvState.Failed) {
    Text("Setup failed during: ${state.step.label}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleMedium)
    SelectionContainer { Text(state.message, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
    LogBox(state.log)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { env.startSetup() }) { Text("Retry / resume") }
        OutlinedButton(onClick = { env.refresh() }) { Text("Back") }
    }
}

@Composable
private fun LogBox(lines: List<String>) {
    if (lines.isEmpty()) return
    Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
        SelectionContainer {
            Text(lines.takeLast(12).joinToString("\n"), fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(8.dp))
        }
    }
}
