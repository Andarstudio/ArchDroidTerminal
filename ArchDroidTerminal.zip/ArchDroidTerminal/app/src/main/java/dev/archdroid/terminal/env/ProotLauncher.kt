package dev.archdroid.terminal.env

import android.system.Os
import dev.archdroid.terminal.data.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.file.Files
import kotlin.coroutines.coroutineContext

data class CommandResult(val exitCode: Int, val output: String)

/** Builds proot command lines/environments and runs non-interactive commands inside the Linux environment. */
class ProotLauncher(private val paths: EnvPaths) {

    fun missingNativeFiles(): List<String> =
        listOf(paths.proot, paths.prootLoader, paths.talloc).filter { !it.exists() }.map { it.name }

    /** Creates helper dirs/files proot needs. Idempotent. */
    fun prepareSupportFiles() {
        paths.prootTmp.mkdirs()
        File(paths.rootfs, "tmp").mkdirs()
        runCatching { Os.chmod(File(paths.rootfs, "tmp").path, 0x3FF) } // 1777
        File(paths.rootfs, "sdcard").mkdirs()

        // libtalloc is shipped as libtalloc.so (APK rule); proot's DT_NEEDED is libtalloc.so.2.
        val libDir = File(paths.support, "lib").apply { mkdirs() }
        val link = File(libDir, "libtalloc.so.2")
        val current = runCatching { Os.readlink(link.path) }.getOrNull()
        if (current != paths.talloc.path) {
            Files.deleteIfExists(link.toPath())
            Os.symlink(paths.talloc.path, link.path)
        }

        // Android hides some /proc files from apps; bind harmless stand-ins (same approach as proot-distro).
        val proc = File(paths.support, "proc").apply { mkdirs() }
        fun put(name: String, text: String) { val f = File(proc, name); if (!f.exists()) f.writeText(text) }
        put("loadavg", "0.12 0.07 0.02 2/165 765\n")
        put("uptime", "1234.56 4321.00\n")
        put("version", "Linux version 6.1.0-archdroid (proot@archdroid) (gcc) #1 SMP\n")
        put("stat", "cpu  1957 0 2877 93280 0 0 0 0 0 0\ncpu0 1957 0 2877 93280 0 0 0 0 0 0\n" +
            "intr 0\nctxt 0\nbtime 1700000000\nprocesses 1\nprocs_running 1\nprocs_blocked 0\n")
    }

    /** Host-side environment for the proot process itself. */
    fun hostEnv(s: AppSettings): Map<String, String> = buildMap {
        put("PROOT_TMP_DIR", paths.prootTmp.path)
        put("PROOT_LOADER", paths.prootLoader.path)
        put("LD_LIBRARY_PATH", "${File(paths.support, "lib").path}:${paths.nativeDir.path}")
        put("TMPDIR", paths.prootTmp.path)
        if (s.prootNoSeccomp) put("PROOT_NO_SECCOMP", "1")
    }

    /** Arguments after the proot binary. [guestCommand] is run inside the rootfs. */
    fun prootArgs(s: AppSettings, guestCommand: List<String>, workDir: String = s.workDir): List<String> {
        val a = mutableListOf(
            "--kill-on-exit", "--link2symlink", "-0",
            "-r", paths.rootfs.path,
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
        )
        for (n in listOf("loadavg", "uptime", "version", "stat")) {
            a += listOf("-b", "${File(paths.support, "proc/$n").path}:/proc/$n")
        }
        a += listOf("-b", "${File(paths.rootfs, "tmp").path}:/dev/shm")
        if (s.mountSharedStorage && File("/storage/emulated/0").canRead()) {
            a += listOf("-b", "/storage/emulated/0:/sdcard")
        }
        a += listOf("-w", workDir)
        a += guestCommand
        return a
    }

    /** `env -i` keeps Android's host environment (LD_LIBRARY_PATH etc.) out of glibc programs. */
    fun guestEnvPrefix(shell: String): List<String> = listOf(
        "/usr/bin/env", "-i",
        "HOME=/root", "USER=root", "LOGNAME=root", "SHELL=$shell",
        "TERM=xterm-256color", "COLORTERM=truecolor", "LANG=C.UTF-8",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/bin",
    )

    fun interactiveShell(s: AppSettings): List<String> = guestEnvPrefix(s.shellPath) + listOf(s.shellPath, "-l")

    /** Runs a command in the guest, streaming merged stdout/stderr lines. Cancellable. */
    suspend fun run(
        s: AppSettings,
        command: List<String>,
        timeoutMs: Long = 0,
        onLine: (String) -> Unit = {},
    ): CommandResult = withContext(Dispatchers.IO) {
        prepareSupportFiles()
        val cmd = listOf(paths.proot.path) + prootArgs(s, guestEnvPrefix("/bin/bash") + command, "/")
        val pb = ProcessBuilder(cmd).directory(paths.filesDir).redirectErrorStream(true)
            .redirectInput(ProcessBuilder.Redirect.from(File("/dev/null")))
        pb.environment().clear()
        pb.environment().putAll(hostEnv(s))
        val proc = pb.start()
        val out = StringBuilder()
        val start = System.currentTimeMillis()
        try {
            proc.inputStream.bufferedReader().use { r ->
                while (true) {
                    coroutineContext.ensureActive()
                    val line = r.readLine() ?: break
                    if (out.length < 200_000) out.appendLine(line)
                    onLine(line)
                    if (timeoutMs > 0 && System.currentTimeMillis() - start > timeoutMs) {
                        proc.destroyForcibly(); break
                    }
                }
            }
            CommandResult(proc.waitFor(), out.toString())
        } finally {
            if (proc.isAlive) proc.destroyForcibly()
        }
    }
}
