package dev.archdroid.terminal.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "archdroid_settings")

enum class ThemeMode(val label: String) { SYSTEM("Follow system"), DARK("Dark"), LIGHT("Light") }
enum class CursorStyle(val label: String) { BLOCK("Block"), UNDERLINE("Underline"), BAR("Bar") }
enum class TermFont(val label: String, val family: String) {
    MONO("Monospace", "monospace"),
    SERIF_MONO("Serif monospace", "serif-monospace"),
}

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val fontSizeSp: Int = 14,
    val font: TermFont = TermFont.MONO,
    val cursorStyle: CursorStyle = CursorStyle.BLOCK,
    val scrollbackRows: Int = 5000,
    /** Absolute path of the login shell INSIDE the Linux environment. */
    val shellPath: String = "/bin/bash",
    /** Absolute path INSIDE the Linux environment. */
    val workDir: String = "/root",
    val keepScreenOn: Boolean = false,
    val haptics: Boolean = true,
    /** Bind Android shared storage at /sdcard inside the Linux environment. */
    val mountSharedStorage: Boolean = false,
    /** Sets PROOT_NO_SECCOMP=1. Slower, but avoids crashes on devices where seccomp acceleration misbehaves. */
    val prootNoSeccomp: Boolean = true,
)

object Keys {
    val THEME = stringPreferencesKey("theme")
    val FONT_SIZE = intPreferencesKey("font_size")
    val FONT = stringPreferencesKey("font")
    val CURSOR = stringPreferencesKey("cursor")
    val SCROLLBACK = intPreferencesKey("scrollback")
    val SHELL = stringPreferencesKey("shell")
    val WORKDIR = stringPreferencesKey("workdir")
    val KEEP_AWAKE = booleanPreferencesKey("keep_awake")
    val HAPTICS = booleanPreferencesKey("haptics")
    val SHARED_STORAGE = booleanPreferencesKey("shared_storage")
    val NO_SECCOMP = booleanPreferencesKey("no_seccomp")
}

class SettingsRepository(private val context: Context) {
    val flow: Flow<AppSettings> = context.dataStore.data.map { it.toSettings() }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        context.dataStore.edit { it[key] = value }
    }

    suspend fun current(): AppSettings = context.dataStore.data.first().toSettings()

    private inline fun <reified E : Enum<E>> Preferences.enum(key: Preferences.Key<String>, default: E): E =
        this[key]?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            theme = enum(Keys.THEME, d.theme),
            fontSizeSp = (this[Keys.FONT_SIZE] ?: d.fontSizeSp).coerceIn(8, 32),
            font = enum(Keys.FONT, d.font),
            cursorStyle = enum(Keys.CURSOR, d.cursorStyle),
            scrollbackRows = (this[Keys.SCROLLBACK] ?: d.scrollbackRows).coerceIn(100, 50_000),
            shellPath = this[Keys.SHELL] ?: d.shellPath,
            workDir = this[Keys.WORKDIR] ?: d.workDir,
            keepScreenOn = this[Keys.KEEP_AWAKE] ?: d.keepScreenOn,
            haptics = this[Keys.HAPTICS] ?: d.haptics,
            mountSharedStorage = this[Keys.SHARED_STORAGE] ?: d.mountSharedStorage,
            prootNoSeccomp = this[Keys.NO_SECCOMP] ?: d.prootNoSeccomp,
        )
    }
}
