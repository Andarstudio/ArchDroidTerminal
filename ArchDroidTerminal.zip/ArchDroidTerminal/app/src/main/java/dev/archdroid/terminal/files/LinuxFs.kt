package dev.archdroid.terminal.files

import android.system.Os
import dev.archdroid.terminal.env.RootfsExtractor
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.LinkOption

data class FsEntry(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val isLink: Boolean,
    val linkTarget: String?,
    val size: Long,
    val modified: Long,
)

/**
 * Browses a directory tree whose absolute symlinks must be interpreted relative to [root]
 * (the Arch rootfs), never against Android's real filesystem. Also used for Android shared storage.
 */
class VirtualFs(private val root: File) {

    fun parts(path: String): List<String> = path.split('/').filter { it.isNotEmpty() && it != "." }

    /** Lexical normalisation for display ("/a/b/../c" -> "/a/c"). */
    fun normalize(path: String): String {
        val out = ArrayList<String>()
        for (p in parts(path)) if (p == "..") { if (out.isNotEmpty()) out.removeAt(out.lastIndex) } else out.add(p)
        return "/" + out.joinToString("/")
    }

    /** Resolves [path] to a host File, following symlinks as the guest would (root-relative). */
    fun resolve(path: String): File {
        val pending = ArrayDeque(parts(path))
        val cur = ArrayList<String>()
        var hops = 0
        while (pending.isNotEmpty()) {
            val part = pending.removeFirst()
            if (part == "..") { if (cur.isNotEmpty()) cur.removeAt(cur.lastIndex); continue }
            val f = File(root, (cur + part).joinToString("/"))
            if (Files.isSymbolicLink(f.toPath())) {
                if (++hops > 40) throw IOException("Too many levels of symbolic links")
                val target = Os.readlink(f.path)
                if (target.startsWith("/")) cur.clear()
                parts(target).reversed().forEach { pending.addFirst(it) }
            } else cur.add(part)
        }
        return if (cur.isEmpty()) root else File(root, cur.joinToString("/"))
    }

    fun list(path: String): List<FsEntry> {
        val dir = resolve(path)
        val base = normalize(path).let { if (it == "/") "" else it }
        val children = dir.listFiles() ?: throw IOException("Cannot read $path")
        return children.map { f ->
            val p = f.toPath()
            val link = Files.isSymbolicLink(p)
            val target = if (link) runCatching { Os.readlink(f.path) }.getOrNull() else null
            val childPath = "$base/${f.name}"
            val isDir = if (link) runCatching { resolve(childPath).isDirectory }.getOrDefault(false) else f.isDirectory
            FsEntry(f.name, childPath, isDir, link, target, if (isDir) 0 else runCatching { Files.size(p) }.getOrDefault(0), f.lastModified())
        }.sortedWith(compareByDescending<FsEntry> { it.isDir }.thenBy { it.name.lowercase() })
    }

    fun readText(path: String, maxBytes: Int = 256 * 1024): String {
        val f = resolve(path)
        if (!f.isFile) throw IOException("Not a regular file")
        f.inputStream().use { return String(it.readNBytes(maxBytes), Charsets.UTF_8) + if (f.length() > maxBytes) "\n… (truncated)" else "" }
    }

    /** Deletes the entry itself; symlinks are removed, never followed. */
    fun delete(path: String) {
        val norm = normalize(path)
        if (norm == "/") throw IOException("Refusing to delete the root directory")
        val name = norm.substringAfterLast('/')
        val parent = resolve(norm.substringBeforeLast('/', "/"))
        RootfsExtractor.deleteTree(File(parent, name))
    }
}
