package dev.archdroid.terminal.env

import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.util.zip.GZIPInputStream
import kotlin.coroutines.coroutineContext

data class ExtractStats(val files: Int, val dirs: Int, val symlinks: Int, val hardlinks: Int, val skipped: Int)

object RootfsExtractor {

    private class CountingStream(input: InputStream) : FilterInputStream(input) {
        @Volatile var count = 0L
        override fun read(): Int = super.read().also { if (it >= 0) count++ }
        override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also { if (it > 0) count += it }
    }

    /**
     * Lexically resolves a tar entry name below [root]. Returns null for empty names and throws for
     * path-traversal attempts (".." components).
     */
    fun resolveEntry(root: File, name: String): File? {
        val parts = name.split('/').filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty()) return null
        if (parts.any { it == ".." }) throw IOException("Refusing path traversal in archive entry: $name")
        return File(root, parts.joinToString("/"))
    }

    /** True if no ancestor between [root] (exclusive) and [target] (exclusive) is a symbolic link. */
    private fun ancestorsAreRealDirs(root: File, target: File): Boolean {
        var p: File? = target.parentFile
        while (p != null && p != root) {
            if (Files.isSymbolicLink(p.toPath())) return false
            p = p.parentFile
        }
        return true
    }

    private fun chmodSafe(file: File, mode: Int, isDir: Boolean) {
        val m = (mode and 0xFFF) or (if (isDir) 0x1C0 else 0x180) // ensure owner rwx (dir) / rw (file)
        try { Os.chmod(file.path, m) } catch (_: Exception) {
            try { Os.chmod(file.path, m and 0x1FF) } catch (_: Exception) { /* best effort */ }
        }
    }

    /**
     * Extracts a .tar.gz into [destRoot]. Preserves symlinks, hard links (falling back to copies) and
     * permission bits; skips device nodes/FIFOs (they are provided by proot's /dev bind at runtime).
     * [onProgress] receives compressed-bytes-read, total compressed size, and the current entry name.
     */
    suspend fun extract(
        tarGz: File,
        destRoot: File,
        onProgress: (read: Long, total: Long, entry: String) -> Unit,
    ): ExtractStats = withContext(Dispatchers.IO) {
        destRoot.mkdirs()
        val total = tarGz.length()
        var files = 0; var dirs = 0; var syms = 0; var hards = 0; var skipped = 0
        var lastReport = 0L

        val counting = CountingStream(FileInputStream(tarGz))
        TarArchiveInputStream(GZIPInputStream(BufferedInputStream(counting, 1 shl 16), 1 shl 16)).use { tar ->
            var entry: TarArchiveEntry? = tar.nextTarEntry
            while (entry != null) {
                coroutineContext.ensureActive()
                val e = entry
                val target = resolveEntry(destRoot, e.name)
                if (target != null) {
                    if (!ancestorsAreRealDirs(destRoot, target)) {
                        throw IOException("Refusing to write through a symbolic link: ${e.name}")
                    }
                    target.parentFile?.mkdirs()
                    when {
                        e.isDirectory -> {
                            if (!target.isDirectory) target.mkdirs()
                            chmodSafe(target, e.mode, true); dirs++
                        }
                        e.isSymbolicLink -> {
                            Files.deleteIfExists(target.toPath())
                            Os.symlink(e.linkName, target.path); syms++
                        }
                        e.isLink -> {
                            val src = resolveEntry(destRoot, e.linkName)
                                ?: throw IOException("Bad hard link target for ${e.name}")
                            Files.deleteIfExists(target.toPath())
                            try { Os.link(src.path, target.path) } catch (_: Exception) {
                                src.copyTo(target, overwrite = true)
                                chmodSafe(target, e.mode, false)
                            }
                            hards++
                        }
                        e.isFile -> {
                            Files.deleteIfExists(target.toPath())
                            target.outputStream().buffered(1 shl 16).use { out -> tar.copyTo(out, 1 shl 16) }
                            chmodSafe(target, e.mode, false); files++
                        }
                        else -> skipped++ // char/block devices, FIFOs
                    }
                }
                val now = System.nanoTime()
                if (now - lastReport > 250_000_000L) {
                    lastReport = now
                    onProgress(counting.count, total, e.name)
                }
                entry = tar.nextTarEntry
            }
        }
        onProgress(total, total, "")
        ExtractStats(files, dirs, syms, hards, skipped)
    }

    /** Deletes a tree without ever following symlinks (rootfs symlinks may point at arbitrary absolute paths). */
    fun deleteTree(root: File) {
        val path: Path = root.toPath()
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return
        Files.walkFileTree(path, object : java.nio.file.SimpleFileVisitor<Path>() {
            override fun preVisitDirectory(dir: Path, attrs: java.nio.file.attribute.BasicFileAttributes): java.nio.file.FileVisitResult {
                try { Os.chmod(dir.toString(), 0x1C0) } catch (_: Exception) {}
                return java.nio.file.FileVisitResult.CONTINUE
            }
            override fun visitFile(file: Path, attrs: java.nio.file.attribute.BasicFileAttributes): java.nio.file.FileVisitResult {
                Files.delete(file); return java.nio.file.FileVisitResult.CONTINUE
            }
            override fun postVisitDirectory(dir: Path, exc: java.io.IOException?): java.nio.file.FileVisitResult {
                Files.delete(dir); return java.nio.file.FileVisitResult.CONTINUE
            }
        })
    }

    /** Total size of regular files below [root], not following symlinks. */
    fun treeSize(root: File): Long {
        val path = root.toPath()
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return 0L
        var sum = 0L
        Files.walkFileTree(path, object : java.nio.file.SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: java.nio.file.attribute.BasicFileAttributes): java.nio.file.FileVisitResult {
                if (attrs.isRegularFile) sum += attrs.size()
                return java.nio.file.FileVisitResult.CONTINUE
            }
            override fun visitFileFailed(file: Path, exc: java.io.IOException): java.nio.file.FileVisitResult =
                java.nio.file.FileVisitResult.CONTINUE
        })
        return sum
    }
}
