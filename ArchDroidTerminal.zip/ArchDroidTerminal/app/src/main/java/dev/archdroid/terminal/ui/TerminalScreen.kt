@file:OptIn(ExperimentalMaterial3Api::class)

package dev.archdroid.terminal.ui

import android.content.Context
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.termux.terminal.TerminalSession
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import dev.archdroid.terminal.app
import dev.archdroid.terminal.data.AppSettings
import dev.archdroid.terminal.data.Keys
import dev.archdroid.terminal.terminal.TerminalPalette
import kotlinx.coroutines.launch

/** Bridges Termux's TerminalView callbacks to app behaviour. Ctrl/Alt are sticky toggles from the extra-keys row. */
private class ViewClient(
    private val onTap: () -> Unit,
    private val onFontDelta: (Int) -> Unit,
    private val haptics: () -> Boolean,
) : TerminalViewClient {
    var ctrl by mutableStateOf(false)
    var alt by mutableStateOf(false)

    override fun onScale(scale: Float): Float {
        if (scale < 0.9f || scale > 1.1f) { onFontDelta(if (scale > 1f) 1 else -1); return 1.0f }
        return scale
    }
    override fun onSingleTapUp(e: MotionEvent?) { onTap() }
    override fun shouldBackButtonBeMappedToEscape() = false
    override fun shouldEnforceCharBasedInput() = true
    override fun shouldUseCtrlSpaceWorkaround() = false
    override fun isTerminalViewSelected() = true
    override fun copyModeChanged(copyMode: Boolean) {}
    override fun onKeyDown(keyCode: Int, e: KeyEvent?, session: TerminalSession?) = false
    override fun onKeyUp(keyCode: Int, e: KeyEvent?) = false
    override fun onLongPress(event: MotionEvent?) = false
    override fun readControlKey() = ctrl
    override fun readAltKey() = alt
    override fun readShiftKey() = false
    override fun readFnKey() = false
    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?): Boolean {
        ctrl = false; alt = false; return false
    }
    override fun onEmulatorSet() {}
    override fun logError(tag: String?, message: String?) { android.util.Log.e(tag, message ?: "") }
    override fun logWarn(tag: String?, message: String?) { android.util.Log.w(tag, message ?: "") }
    override fun logInfo(tag: String?, message: String?) { android.util.Log.i(tag, message ?: "") }
    override fun logDebug(tag: String?, message: String?) { android.util.Log.d(tag, message ?: "") }
    override fun logVerbose(tag: String?, message: String?) { android.util.Log.v(tag, message ?: "") }
    override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) { android.util.Log.e(tag, message, e) }
    override fun logStackTrace(tag: String?, e: Exception?) { android.util.Log.e(tag, "error", e) }
}

@Composable
fun TerminalScreen(dark: Boolean, onFiles: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.app
    val sm = app.sessions
    val scope = rememberCoroutineScope()
    val infos by sm.infos.collectAsStateWithLifecycle()
    val activeId by sm.activeId.collectAsStateWithLifecycle()
    val st by app.settings.flow.collectAsStateWithLifecycle(AppSettings())
    val hostView = LocalView.current
    var termView by remember { mutableStateOf<TerminalView?>(null) }
    var menu by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { if (sm.count == 0) sm.create() }
    LaunchedEffect(dark) { TerminalPalette.apply(dark); sm.applyColors(); termView?.setBackgroundColor(TerminalPalette.backgroundArgb(dark)) }
    LaunchedEffect(st.cursorStyle) { sm.applyCursorStyle(st.cursorStyle) }
    DisposableEffect(st.keepScreenOn) { hostView.keepScreenOn = st.keepScreenOn; onDispose { hostView.keepScreenOn = false } }

    val latest = rememberUpdatedState(st)
    val client = remember {
        ViewClient(
            onTap = { termView?.let { v -> v.requestFocus(); (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, 0) } },
            onFontDelta = { d -> scope.launch { app.settings.set(Keys.FONT_SIZE, (latest.value.fontSizeSp + d).coerceIn(8, 32)) } },
            haptics = { latest.value.haptics },
        )
    }
    DisposableEffect(Unit) { onDispose { sm.attachView(null) } }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
                items(infos, key = { it.id }) { i ->
                    FilterChip(
                        selected = i.id == activeId, onClick = { sm.setActive(i.id) },
                        label = { Text(if (i.finished) "${i.title} ✕" else i.title, maxLines = 1) },
                        trailingIcon = { Icon(Icons.Default.Close, "Close session", Modifier.size(16.dp).clickable { sm.close(i.id) }) },
                    )
                }
            }
            IconButton({ scope.launch { sm.create() } }) { Icon(Icons.Default.Add, "New session") }
            IconButton({
                termView?.let { v -> v.requestFocus(); (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0) }
            }) { Icon(Icons.Default.Keyboard, "Toggle keyboard") }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Paste") }, onClick = { menu = false; sm.paste(activeId) })
                    DropdownMenuItem(text = { Text("Clear screen (Ctrl+L)") }, onClick = { menu = false; sm.sessionFor(activeId)?.write("\u000c") })
                    DropdownMenuItem(text = { Text("Files") }, onClick = { menu = false; onFiles() })
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; onSettings() })
                }
            }
        }

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { c ->
                TerminalView(c, null).apply {
                    setTerminalViewClient(client)
                    isFocusable = true; isFocusableInTouchMode = true
                    setBackgroundColor(TerminalPalette.backgroundArgb(dark))
                    sm.attachView(this); termView = this
                }
            },
            update = { v ->
                val s = sm.sessionFor(activeId)
                if (s != null && v.currentSession !== s) { v.attachSession(s); v.requestFocus() }
                val px = (st.fontSizeSp * v.resources.displayMetrics.scaledDensity).toInt()
                if (v.getTag() != px) { v.setTag(px); v.setTextSize(px) }
                v.setTypeface(Typeface.create(st.font.family, Typeface.NORMAL))
                v.onScreenUpdated()
            },
        )

        ExtraKeys(client, st.haptics, hostView) { sm.sessionFor(activeId) }
    }
}

@Composable
private fun ExtraKeys(client: ViewClient, haptics: Boolean, host: android.view.View, session: () -> TerminalSession?) {
    fun send(s: String) { if (haptics) host.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); session()?.write(s) }
    fun arrow(c: Char): String = if (session()?.emulator?.isCursorKeysApplicationMode == true) "\u001bO$c" else "\u001b[$c"
    @Composable fun key(label: String, onClick: () -> Unit) =
        FilledTonalButton(onClick, contentPadding = PaddingValues(horizontal = 10.dp), modifier = Modifier.heightIn(min = 38.dp)) { Text(label) }

    LazyRow(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), contentPadding = PaddingValues(horizontal = 6.dp)) {
        item { key("ESC") { send("\u001b") } }
        item { key("TAB") { send("\t") } }
        item { FilterChip(client.ctrl, { client.ctrl = !client.ctrl }, label = { Text("CTRL") }) }
        item { FilterChip(client.alt, { client.alt = !client.alt }, label = { Text("ALT") }) }
        item { key("^C") { send("\u0003") } }
        item { key("^D") { send("\u0004") } }
        item { key("←") { send(arrow('D')) } }
        item { key("↓") { send(arrow('B')) } }
        item { key("↑") { send(arrow('A')) } }
        item { key("→") { send(arrow('C')) } }
        for (c in listOf("-", "/", "|", "~", "\\", "_")) item { key(c) { send(c) } }
    }
}
