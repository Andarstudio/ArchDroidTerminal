@file:OptIn(ExperimentalMaterial3Api::class)

package dev.archdroid.terminal.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.archdroid.terminal.BuildConfig
import dev.archdroid.terminal.app
import dev.archdroid.terminal.data.*
import dev.archdroid.terminal.env.StorageUsage
import dev.archdroid.terminal.env.formatBytes
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit, onAbout: () -> Unit) {
    val app = LocalContext.current.app
    val scope = rememberCoroutineScope()
    val s by app.settings.flow.collectAsStateWithLifecycle(AppSettings())
    val infos by app.sessions.infos.collectAsStateWithLifecycle()
    var status by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var usage by remember { mutableStateOf<StorageUsage?>(null) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var alsoDownloads by remember { mutableStateOf(false) }
    var shell by remember(s.shellPath) { mutableStateOf(s.shellPath) }
    var wd by remember(s.workDir) { mutableStateOf(s.workDir) }

    LaunchedEffect(Unit) { usage = app.env.storageUsage(); status = app.env.statusReport() }
    fun <T> save(k: Preferences.Key<T>, v: T) { scope.launch { app.settings.set(k, v) } }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Header("Appearance")
            Choice("Theme", ThemeMode.entries, s.theme, { it.label }) { save(Keys.THEME, it.name) }
            Choice("Font", TermFont.entries, s.font, { it.label }) { save(Keys.FONT, it.name) }
            Text("Font size: ${s.fontSizeSp} sp")
            Slider(s.fontSizeSp.toFloat(), { save(Keys.FONT_SIZE, it.toInt()) }, valueRange = 8f..32f, steps = 23)
            Choice("Cursor style", CursorStyle.entries, s.cursorStyle, { it.label }) { save(Keys.CURSOR, it.name) }
            Text("Scrollback: ${s.scrollbackRows} rows (applies to new sessions)")
            Slider(s.scrollbackRows.toFloat(), { save(Keys.SCROLLBACK, (it / 100).toInt() * 100) }, valueRange = 500f..50000f)
            Toggle("Keep screen awake", s.keepScreenOn) { save(Keys.KEEP_AWAKE, it) }
            Toggle("Haptic feedback on extra keys", s.haptics) { save(Keys.HAPTICS, it) }

            Header("Shell (applies to new sessions)")
            OutlinedTextField(shell, { shell = it }, label = { Text("Login shell inside Linux") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(wd, { wd = it }, label = { Text("Default working directory inside Linux") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button({ save(Keys.SHELL, shell.trim().ifEmpty { "/bin/bash" }); save(Keys.WORKDIR, wd.trim().ifEmpty { "/root" }) }) { Text("Save shell settings") }
            Toggle("Mount Android shared storage at /sdcard (needs storage permission, set in Files)", s.mountSharedStorage) { save(Keys.SHARED_STORAGE, it) }
            Toggle("proot compatibility mode (PROOT_NO_SECCOMP=1; slower, more compatible)", s.prootNoSeccomp) { save(Keys.NO_SECCOMP, it) }

            Header("Terminal sessions")
            if (infos.isEmpty()) Text("No open sessions.")
            infos.forEach { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${it.title}${if (it.finished) " (exited)" else ""}", Modifier.weight(1f))
                TextButton({ app.sessions.close(it.id) }) { Text("Close") }
            } }
            if (infos.isNotEmpty()) OutlinedButton({ app.sessions.closeAll() }) { Text("Close all sessions") }

            Header("Linux environment")
            status?.forEach { (k, v) -> Text("$k: $v") } ?: Text("Checking…")
            usage?.let { Text("Storage: Linux filesystem ${formatBytes(it.rootfsBytes)}, downloaded archive ${formatBytes(it.downloadBytes)}, device free ${formatBytes(it.freeBytes)}") }
            OutlinedButton({ confirm = "unlock" }) { Text("Remove stale pacman lock (db.lck)") }
            OutlinedButton({ confirm = "repair" }) { Text("Repair environment") }
            Button({ confirm = "reset" }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Reset environment…") }

            Header("About")
            Text("Version ${BuildConfig.VERSION_NAME}")
            OutlinedButton(onAbout) { Text("About, licenses and limitations") }
        }
    }

    confirm?.let { what ->
        val (title, body) = when (what) {
            "reset" -> "Reset the Linux environment?" to "This permanently deletes the entire Arch Linux filesystem: every installed package and every file in your Linux home directory. All terminal sessions are closed. You will have to run setup again."
            "repair" -> "Repair the environment?" to "Rewrites DNS/hosts/pacman/bash defaults, removes a stale pacman lock and re-initialises the pacman keyring. Your files and packages are kept. Terminal sessions are closed."
            else -> "Remove pacman's lock file?" to "Only do this if no pacman process is running (e.g. after an interrupted install). Close other sessions first."
        }
        AlertDialog(
            onDismissRequest = { confirm = null }, title = { Text(title) },
            text = { Column {
                Text(body)
                if (what == "reset") Row(Modifier.clickable { alsoDownloads = !alsoDownloads }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(alsoDownloads, { alsoDownloads = it }); Text("Also delete the downloaded archive")
                }
            } },
            confirmButton = { TextButton({
                when (what) {
                    "reset" -> { app.sessions.closeAll(); scope.launch { app.env.reset(alsoDownloads) } }
                    "repair" -> { app.sessions.closeAll(); app.env.startRepair() }
                    else -> app.env.clearPacmanLock()
                }
                confirm = null
            }) { Text("Confirm") } },
            dismissButton = { TextButton({ confirm = null }) { Text("Cancel") } },
        )
    }
}

@Composable private fun Header(t: String) { Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 10.dp)) }

@Composable private fun Toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(value, onChange) }
}

@Composable private fun <T> Choice(label: String, options: List<T>, selected: T, name: (T) -> String, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Box {
            OutlinedButton({ open = true }) { Text(name(selected)) }
            DropdownMenu(open, { open = false }) { options.forEach { o -> DropdownMenuItem(text = { Text(name(o)) }, onClick = { open = false; onSelect(o) }) } }
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("About") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("ArchDroid Terminal ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleLarge)
            Text("A rootless Arch Linux ARM userspace for Android, run through proot. It is not a virtual machine and does not run a Linux kernel of its own.")
            Header("Limitations")
            Text("• Isolation is weaker than a VM: proot intercepts system calls with ptrace and fakes root (uid 0) only inside the guest.\n" +
                "• No systemd/services, no kernel modules, no mounting filesystems, no real privileged operations, no iptables/containers.\n" +
                "• Some programs that need unusual syscalls, /proc or /sys details, or ptrace themselves (debuggers, some browsers/Electron apps) may fail.\n" +
                "• Performance is lower than native because of proot syscall interception.\n" +
                "• Arch Linux ARM is a separate project from Arch Linux: different mirrors and package set, community-maintained for ARM.\n" +
                "• The rootfs download is checked against the published MD5 from the same server. The GPG signature (.sig) is not verified in-app.")
            Header("Licenses and attribution")
            Text("• Arch Linux ARM root filesystem and packages: various licenses; https://archlinuxarm.org\n" +
                "• proot (GPL-2.0-or-later) and its loader, libtalloc (LGPL-3.0-or-later): built by the Termux project, https://github.com/termux/proot\n" +
                "• Termux terminal-emulator / terminal-view (Apache-2.0): https://github.com/termux/termux-app\n" +
                "• AndroidX / Jetpack Compose (Apache-2.0), Kotlin coroutines (Apache-2.0), OkHttp (Apache-2.0), Apache Commons Compress (Apache-2.0)\n" +
                "See LICENSES.md in the source tree for the complete list.")
        }
    }
}
