package dev.archdroid.terminal.env

import android.content.Context
import android.system.Os
import dev.archdroid.terminal.data.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.file.Files
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SetupStep(val label: String) {
    PRECHECKS("Checking device"),
    DOWNLOAD("Downloading root filesystem"),
    VERIFY("Verifying download"),
    EXTRACT("Extracting"),
    CONFIGURE("Configuring"),
    KEYRING("Initializing pacman keyring"),
    FINAL_CHECK("Final verification"),
}

data class SetupProgress(val step: SetupStep, val fraction: Float?, val detail: String, val log: List<String>)

sealed interface EnvState {
    data object Checking : EnvState
    data class NeedsSetup(val note: String? = null) : EnvState
    data class SettingUp(val progress: SetupProgress, val repair: Boolean) : EnvState
    data class Failed(val step: SetupStep, val message: String, val log: List<String>) : EnvState
    data object Ready : EnvState
}

data class Preflight(
    val arm64: Boolean,
    val abis: String,
    val freeBytes: Long,
    val requiredBytes: Long,
    val network: Boolean,
    val metered: Boolean,
    val downloadBytes: Long?,
    val partialBytes: Long,
    val missingNative: List<String>,
    val networkError: String?,
) {
    val problems: List<String>
        get() = buildList {
            if (!arm64) add("This device does not support arm64-v8a (ABIs: $abis). The Arch Linux ARM aarch64 rootfs cannot run here.")
            if (missingNative.isNotEmpty()) add("Missing bundled proot components: ${missingNative.joinToString()}. Run scripts/fetch-proot.ps1 and rebuild (see README).")
            if (!network) add("No internet connection.")
            else if (networkError != null) add("Could not reach the Arch Linux ARM download server (${ArchArm.BASE_URL}): $networkError")
            if (freeBytes < requiredBytes) add("Not enough free storage: need about ${formatBytes(requiredBytes)}, have ${formatBytes(freeBytes)}.")
        }
    val ok get() = problems.isEmpty()
}

data class StorageUsage(val rootfsBytes: Long, val downloadBytes: Long, val freeBytes: Long)

private class SetupException(message: String) : Exception(message)

class EnvironmentManager(private val context: Context, private val settings: SettingsRepository) {
    val paths = EnvPaths(context)
    val proot = ProotLauncher(paths)
    private val downloader = Downloader()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    private val _state = MutableStateFlow<EnvState>(EnvState.Checking)
    val state: StateFlow<EnvState> = _state.asStateFlow()

    private val log = ArrayDeque<String>()

    init { refresh() }

    fun isInstalled(): Boolean =
        paths.marker.exists() && File(paths.rootfs, "usr/bin/pacman").exists() && File(paths.rootfs, "usr/bin/bash").exists()

    fun refresh() {
        if (job?.isActive == true) return
        _state.value = if (isInstalled()) EnvState.Ready else EnvState.NeedsSetup(
            if (paths.tarballPart.exists()) "A partial download of ${formatBytes(paths.tarballPart.length())} was found and will be resumed." else null
        )
    }

    suspend fun preflight(): Preflight = withContext(Dispatchers.IO) {
        val net = DeviceChecks.hasNetwork(context)
        var size: Long? = null
        var err: String? = null
        if (net) try { size = downloader.contentLength(ArchArm.TARBALL_URL) } catch (e: Exception) { err = e.message ?: e.javaClass.simpleName }
        val required = (size ?: 700L * 1024 * 1024) * 4
        Preflight(
            arm64 = DeviceChecks.supportsArm64(), abis = DeviceChecks.abis(),
            freeBytes = DeviceChecks.freeBytes(paths.filesDir), requiredBytes = required,
            network = net, metered = net && DeviceChecks.isMetered(context),
            downloadBytes = size, partialBytes = if (paths.tarballPart.exists()) paths.tarballPart.length() else 0L,
            missingNative = proot.missingNativeFiles(), networkError = err,
        )
    }

    fun startSetup() = launchPipeline(repairOnly = false)
    fun startRepair() = launchPipeline(repairOnly = true)
    fun cancel() { job?.cancel() }

    private fun launchPipeline(repairOnly: Boolean) {
        if (job?.isActive == true) return
        log.clear()
        job = scope.launch { runPipeline(repairOnly && File(paths.rootfs, "usr/bin/bash").exists()) }
    }

    private fun addLog(line: String) { log.addLast(line); while (log.size > 200) log.removeFirst() }

    private var currentStep = SetupStep.PRECHECKS
    private var repairMode = false
    private fun progress(step: SetupStep, fraction: Float?, detail: String) {
        currentStep = step
        _state.value = EnvState.SettingUp(SetupProgress(step, fraction, detail, log.toList()), repairMode)
    }

    private suspend fun runPipeline(repairOnly: Boolean) {
        repairMode = repairOnly
        try {
            val s = settings.current()
            if (!repairOnly) {
                progress(SetupStep.PRECHECKS, null, "Checking device, storage and network…")
                val pf = preflight()
                if (!pf.ok) throw SetupException(pf.problems.joinToString("\n"))
                addLog("arm64 ok (${pf.abis}); free ${formatBytes(pf.freeBytes)}; download ${pf.downloadBytes?.let(::formatBytes) ?: "unknown size"}")

                val md5Text = downloader.fetchText(ArchArm.MD5_URL)
                val expectedMd5 = Downloader.parseMd5(md5Text, ArchArm.TARBALL)
                    ?: throw SetupException("Could not read an MD5 checksum from ${ArchArm.MD5_URL}. Refusing to continue without a checksum.")
                addLog("Published MD5: $expectedMd5")

                var attempt = 0
                var sha256 = ""
                while (true) {
                    if (!paths.tarball.exists()) {
                        progress(SetupStep.DOWNLOAD, null, "Connecting…")
                        downloader.download(ArchArm.TARBALL_URL, paths.tarball) { done, total ->
                            progress(SetupStep.DOWNLOAD, if (total > 0) done.toFloat() / total else null,
                                "${formatBytes(done)} of ${if (total > 0) formatBytes(total) else "?"}")
                        }
                    }
                    progress(SetupStep.VERIFY, 0f, "Computing checksums…")
                    val d = downloader.digests(paths.tarball) { done, total ->
                        progress(SetupStep.VERIFY, done.toFloat() / total.coerceAtLeast(1), "${formatBytes(done)} of ${formatBytes(total)}")
                    }
                    if (d.md5 == expectedMd5) { sha256 = d.sha256; addLog("MD5 matches. SHA-256: ${d.sha256}"); break }
                    addLog("MD5 mismatch: expected $expectedMd5, got ${d.md5}")
                    paths.tarball.delete(); paths.tarballPart.delete()
                    if (++attempt >= 2) throw SetupException("Checksum mismatch after re-downloading (expected $expectedMd5, got ${d.md5}). Not installing.")
                }

                progress(SetupStep.EXTRACT, 0f, "Preparing…")
                if (paths.rootfsTmp.exists()) RootfsExtractor.deleteTree(paths.rootfsTmp)
                val stats = RootfsExtractor.extract(paths.tarball, paths.rootfsTmp) { read, total, entry ->
                    progress(SetupStep.EXTRACT, read.toFloat() / total.coerceAtLeast(1), entry)
                }
                addLog("Extracted ${stats.files} files, ${stats.dirs} dirs, ${stats.symlinks} symlinks, ${stats.hardlinks} hard links, skipped ${stats.skipped} special files")
                withContext(Dispatchers.IO) {
                    paths.marker.delete()
                    if (paths.rootfs.exists()) RootfsExtractor.deleteTree(paths.rootfs)
                    if (!paths.rootfsTmp.renameTo(paths.rootfs)) throw SetupException("Could not move the extracted filesystem into place")
                    File(paths.filesDir, "env.sha256").writeText(sha256)
                }
            }

            progress(SetupStep.CONFIGURE, null, "Writing configuration…")
            withContext(Dispatchers.IO) { configureGuest() }
            proot.prepareSupportFiles()

            progress(SetupStep.KEYRING, null, "pacman-key --init")
            withContext(Dispatchers.IO) { Files.deleteIfExists(File(paths.rootfs, "var/lib/pacman/db.lck").toPath()) }
            for (cmd in listOf(listOf("/usr/bin/pacman-key", "--init"), listOf("/usr/bin/pacman-key", "--populate", "archlinuxarm"))) {
                progress(SetupStep.KEYRING, null, cmd.drop(1).joinToString(" "))
                val r = proot.run(s, cmd) { line -> addLog(line); progress(SetupStep.KEYRING, null, line.take(120)) }
                if (r.exitCode != 0) throw SetupException("`${cmd.joinToString(" ")}` failed with exit code ${r.exitCode}:\n${r.output.takeLast(1500)}")
            }

            progress(SetupStep.FINAL_CHECK, null, "Verifying the environment…")
            val un = proot.run(s, listOf("/usr/bin/uname", "-m"))
            if (un.exitCode != 0 || un.output.trim() != "aarch64") throw SetupException("Guest `uname -m` returned '${un.output.trim()}' (exit ${un.exitCode}); expected aarch64.")
            val os = proot.run(s, listOf("/usr/bin/cat", "/etc/os-release"))
            if (os.exitCode != 0 || !os.output.contains("arch", ignoreCase = true)) throw SetupException("/etc/os-release does not identify an Arch-based system.")
            val pm = proot.run(s, listOf("/usr/bin/pacman", "--version"))
            if (pm.exitCode != 0 || !pm.output.contains("pacman", ignoreCase = true)) throw SetupException("`pacman --version` failed (exit ${pm.exitCode}):\n${pm.output.takeLast(800)}")
            addLog(pm.output.lines().firstOrNull { it.contains("Pacman", true) }?.trim() ?: "pacman ok")
            withContext(Dispatchers.IO) {
                val sha = File(paths.filesDir, "env.sha256").takeIf { it.exists() }?.readText().orEmpty()
                paths.marker.writeText("verified=${stamp()}\ntarball_sha256=$sha\n")
            }
            _state.value = EnvState.Ready
        } catch (e: CancellationException) {
            _state.value = EnvState.NeedsSetup("Setup was cancelled. Downloaded data is kept; press Start to resume.")
            throw e
        } catch (e: Exception) {
            _state.value = EnvState.Failed(currentStep, e.message ?: e.javaClass.simpleName, log.toList())
        }
    }

    private fun stamp() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    /** Idempotent guest configuration (DNS, hosts, pacman.conf for proot, bash defaults). */
    internal fun configureGuest() {
        val root = paths.rootfs
        fun write(rel: String, text: String) {
            val f = File(root, rel)
            f.parentFile?.mkdirs()
            Files.deleteIfExists(f.toPath()) // replace symlinks (e.g. resolv.conf) instead of writing through them
            f.writeText(text)
            runCatching { Os.chmod(f.path, 0x1A4) } // 0644
        }
        write("etc/resolv.conf", "nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        write("etc/hosts", "127.0.0.1 localhost\n::1 localhost\n127.0.1.1 archdroid\n")
        write("etc/hostname", "archdroid\n")
        val pc = File(root, "etc/pacman.conf")
        if (pc.exists()) write("etc/pacman.conf", PacmanConf.patch(pc.readText()))
        val rc = File(root, "root/.bashrc")
        val existing = if (rc.exists()) rc.readText() else ""
        if (!existing.contains(GuestFiles.BASHRC_MARK)) write("root/.bashrc", existing + "\n" + GuestFiles.BASHRC)
        if (!File(root, "root/.bash_profile").exists()) write("root/.bash_profile", "[[ -f ~/.bashrc ]] && . ~/.bashrc\n")
        File(root, "home/user").mkdirs()
    }

    fun clearPacmanLock(): Boolean = Files.deleteIfExists(File(paths.rootfs, "var/lib/pacman/db.lck").toPath())

    suspend fun storageUsage(): StorageUsage = withContext(Dispatchers.IO) {
        StorageUsage(RootfsExtractor.treeSize(paths.rootfs), RootfsExtractor.treeSize(paths.downloads), DeviceChecks.freeBytes(paths.filesDir))
    }

    /** Status lines for Settings. Runs real commands in the guest when installed. */
    suspend fun statusReport(): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        out += "Device ABIs" to DeviceChecks.abis()
        out += "proot components" to (proot.missingNativeFiles().let { if (it.isEmpty()) "present" else "missing: ${it.joinToString()}" })
        out += "Environment" to if (isInstalled()) "installed and verified" else "not installed"
        if (isInstalled()) {
            val s = settings.current()
            runCatching {
                out += "Guest architecture" to proot.run(s, listOf("/usr/bin/uname", "-m"), 30_000).output.trim()
                out += "pacman" to (proot.run(s, listOf("/usr/bin/pacman", "--version"), 30_000).output.lines().firstOrNull { it.contains("Pacman") }?.trim() ?: "unavailable")
            }.onFailure { out += "Guest check" to "failed: ${it.message}" }
            File(paths.marker.path).takeIf { it.exists() }?.readLines()?.firstOrNull { it.startsWith("verified=") }?.let { out += "Last verified" to it.removePrefix("verified=") }
        }
        return out
    }

    /** Destroys the Linux filesystem. Callers must have asked the user for confirmation and closed sessions. */
    suspend fun reset(deleteDownloads: Boolean) = withContext(Dispatchers.IO) {
        paths.marker.delete()
        RootfsExtractor.deleteTree(paths.rootfs)
        RootfsExtractor.deleteTree(paths.rootfsTmp)
        RootfsExtractor.deleteTree(paths.prootTmp)
        if (deleteDownloads) RootfsExtractor.deleteTree(paths.downloads)
        _state.value = EnvState.NeedsSetup(null)
    }
}
