package dev.archdroid.terminal.terminal

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.termux.terminal.TerminalEmulator
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import dev.archdroid.terminal.data.CursorStyle
import dev.archdroid.terminal.data.SettingsRepository
import dev.archdroid.terminal.env.EnvironmentManager
import dev.archdroid.terminal.service.SessionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

data class SessionInfo(val id: Int, val title: String, val finished: Boolean)

/** Owns all terminal sessions. Lives in the Application, so sessions survive Activity recreation. */
class SessionManager(
    private val context: Context,
    private val env: EnvironmentManager,
    private val settings: SettingsRepository,
) {
    private class Entry(val id: Int, val session: TerminalSession, var title: String, var finished: Boolean = false)

    private val main = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<Entry>()
    private var nextId = 1
    private var viewRef: WeakReference<TerminalView>? = null
    @Volatile var cursorStyle: CursorStyle = CursorStyle.BLOCK

    private val _infos = MutableStateFlow<List<SessionInfo>>(emptyList())
    val infos: StateFlow<List<SessionInfo>> = _infos.asStateFlow()
    private val _active = MutableStateFlow(-1)
    val activeId: StateFlow<Int> = _active.asStateFlow()

    fun attachView(v: TerminalView?) { viewRef = v?.let { WeakReference(it) } }
    private fun view() = viewRef?.get()

    fun sessionFor(id: Int): TerminalSession? = entries.firstOrNull { it.id == id }?.session
    fun setActive(id: Int) { if (entries.any { it.id == id }) _active.value = id }
    val count: Int get() = entries.size

    private fun publish() {
        _infos.value = entries.map { SessionInfo(it.id, it.title, it.finished) }
    }

    /** Creates a real shell session: proot -> /bin/bash in the Arch rootfs, attached to a PTY by Termux's native code. */
    suspend fun create(): Int {
        val s = settings.current()
        cursorStyle = s.cursorStyle
        env.proot.prepareSupportFiles()
        val argv = listOf("proot") + env.proot.prootArgs(s, env.proot.interactiveShell(s))
        val envArr = env.proot.hostEnv(s).map { "${it.key}=${it.value}" }.toTypedArray()
        val id = nextId++
        val session = TerminalSession(
            env.paths.proot.path, env.paths.filesDir.path, argv.toTypedArray(), envArr, s.scrollbackRows, Client(id),
        )
        main.post {
            entries += Entry(id, session, "Session $id")
            _active.value = id
            publish()
            ContextCompat.startForegroundService(context, Intent(context, SessionService::class.java))
        }
        return id
    }

    fun close(id: Int) = main.post {
        val e = entries.firstOrNull { it.id == id } ?: return@post
        e.session.finishIfRunning()
        entries.remove(e)
        if (_active.value == id) _active.value = entries.lastOrNull()?.id ?: -1
        publish()
        if (entries.isEmpty()) context.stopService(Intent(context, SessionService::class.java))
    }

    fun closeAll() = main.post {
        entries.forEach { it.session.finishIfRunning() }
        entries.clear(); _active.value = -1; publish()
        context.stopService(Intent(context, SessionService::class.java))
    }

    fun applyCursorStyle(style: CursorStyle) {
        cursorStyle = style
        view()?.let { it.invalidate() }
    }

    fun applyColors() {
        entries.forEach { it.session.emulator?.mColors?.reset() }
        view()?.onScreenUpdated()
    }

    fun paste(id: Int) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString() ?: return
        sessionFor(id)?.emulator?.paste(text)
    }

    private inner class Client(private val id: Int) : TerminalSessionClient {
        override fun onTextChanged(changedSession: TerminalSession) { view()?.onScreenUpdated() }
        override fun onTitleChanged(changedSession: TerminalSession) {
            val t = changedSession.title ?: return
            entries.firstOrNull { it.id == id }?.let { it.title = t.take(24); publish() }
        }
        override fun onSessionFinished(finishedSession: TerminalSession) {
            val e = entries.firstOrNull { it.id == id } ?: return
            e.finished = true
            val msg = "\r\n[Process exited with code ${finishedSession.exitStatus}. Close this tab or open a new session.]\r\n".toByteArray()
            finishedSession.emulator?.append(msg, msg.size)
            publish(); view()?.onScreenUpdated()
        }
        override fun onCopyTextToClipboard(session: TerminalSession, text: String?) {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("terminal", text ?: ""))
        }
        override fun onPasteTextFromClipboard(session: TerminalSession?) { paste(id) }
        override fun onBell(session: TerminalSession) {}
        override fun onColorsChanged(session: TerminalSession) { view()?.onScreenUpdated() }
        override fun onTerminalCursorStateChange(state: Boolean) { view()?.onScreenUpdated() }
        override fun getTerminalCursorStyle(): Int = when (cursorStyle) {
            CursorStyle.BLOCK -> TerminalEmulator.TERMINAL_CURSOR_STYLE_BLOCK
            CursorStyle.UNDERLINE -> TerminalEmulator.TERMINAL_CURSOR_STYLE_UNDERLINE
            CursorStyle.BAR -> TerminalEmulator.TERMINAL_CURSOR_STYLE_BAR
        }
        override fun logError(tag: String?, message: String?) { android.util.Log.e(tag, message ?: "") }
        override fun logWarn(tag: String?, message: String?) { android.util.Log.w(tag, message ?: "") }
        override fun logInfo(tag: String?, message: String?) { android.util.Log.i(tag, message ?: "") }
        override fun logDebug(tag: String?, message: String?) { android.util.Log.d(tag, message ?: "") }
        override fun logVerbose(tag: String?, message: String?) { android.util.Log.v(tag, message ?: "") }
        override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) { android.util.Log.e(tag, message, e) }
        override fun logStackTrace(tag: String?, e: Exception?) { android.util.Log.e(tag, "error", e) }
    }
}
