@file:OptIn(ExperimentalMaterial3Api::class)

package dev.archdroid.terminal.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import dev.archdroid.terminal.app
import dev.archdroid.terminal.env.formatBytes
import dev.archdroid.terminal.files.FsEntry
import dev.archdroid.terminal.files.VirtualFs
import java.io.File
import java.text.DateFormat
import java.util.Date

@Composable
fun FilesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val env = ctx.app.env
    val linux = remember { VirtualFs(env.paths.rootfs) }
    val shared = remember { VirtualFs(File("/storage/emulated/0")) }
    var useShared by remember { mutableStateOf(false) }
    var path by remember { mutableStateOf("/root") }
    var entries by remember { mutableStateOf<List<FsEntry>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var viewing by remember { mutableStateOf<Pair<String, String>?>(null) }
    var deleting by remember { mutableStateOf<FsEntry?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var hasPerm by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        hasPerm = r[Manifest.permission.READ_EXTERNAL_STORAGE] == true
    }
    val fs = if (useShared) shared else linux

    LaunchedEffect(path, useShared, tick, hasPerm) {
        error = null
        if (useShared && !hasPerm) { entries = emptyList(); return@LaunchedEffect }
        runCatching { fs.list(path) }.onSuccess { entries = it }.onFailure { entries = emptyList(); error = it.message }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Files") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { IconButton({ tick++ }) { Icon(Icons.Default.Refresh, "Refresh") } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                SegmentedButton(!useShared, { useShared = false; path = "/root" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Linux (Arch)") }
                SegmentedButton(useShared, { useShared = true; path = "/" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Android shared") }
            }
            Text(
                if (useShared) "Android path: /storage/emulated/0${if (path == "/") "" else path}   (appears as /sdcard in Linux if enabled in Settings)"
                else "Linux path: $path   (stored privately inside the app)",
                Modifier.padding(12.dp), fontFamily = FontFamily.Monospace, fontSize = 12.sp,
            )
            if (useShared && !hasPerm) {
                Column(Modifier.padding(12.dp)) {
                    Text("Reading Android shared storage needs the storage permission.")
                    Button({ permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)) }) { Text("Grant permission") }
                }
            }
            error?.let { Text(it, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.error) }
            LazyColumn(Modifier.weight(1f)) {
                if (path != "/") item {
                    ListItem(headlineContent = { Text("..") }, leadingContent = { Icon(Icons.Default.ArrowUpward, null) },
                        modifier = Modifier.clickable { path = fs.normalize("$path/..") })
                }
                items(entries, key = { it.path }) { e ->
                    ListItem(
                        headlineContent = { Text(e.name) },
                        supportingContent = {
                            Text(buildString {
                                if (e.isLink) append("→ ${e.linkTarget}  ")
                                if (!e.isDir) append(formatBytes(e.size)).append("  ")
                                append(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(e.modified)))
                            }, fontSize = 11.sp)
                        },
                        leadingContent = { Icon(if (e.isDir) Icons.Default.Folder else Icons.Default.Description, null) },
                        trailingContent = { IconButton({ deleting = e }) { Icon(Icons.Default.Delete, "Delete") } },
                        modifier = Modifier.clickable {
                            if (e.isDir) path = e.path
                            else runCatching { fs.readText(e.path) }.onSuccess { viewing = e.name to it }.onFailure { error = it.message }
                        },
                    )
                }
            }
        }
    }

    viewing?.let { (name, text) ->
        AlertDialog(onDismissRequest = { viewing = null }, confirmButton = { TextButton({ viewing = null }) { Text("Close") } }, title = { Text(name) },
            text = { Box(Modifier.verticalScroll(rememberScrollState())) { SelectionContainer { Text(text, fontFamily = FontFamily.Monospace, fontSize = 11.sp) } } })
    }
    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete ${e.name}?") },
            text = { Text("This permanently deletes ${if (useShared) "Android" else "Linux"} path ${e.path}${if (e.isDir) " and everything inside it" else ""}. It cannot be undone.") },
            confirmButton = { TextButton({ runCatching { fs.delete(e.path) }.onFailure { error = it.message }; deleting = null; tick++ }) { Text("Delete") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancel") } },
        )
    }
}
