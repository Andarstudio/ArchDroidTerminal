package dev.archdroid.terminal.env

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.StatFs
import java.io.File

object DeviceChecks {
    fun supportsArm64(): Boolean = Build.SUPPORTED_ABIS.contains("arm64-v8a")
    fun abis(): String = Build.SUPPORTED_ABIS.joinToString(", ")

    fun freeBytes(dir: File): Long {
        dir.mkdirs()
        return StatFs(dir.path).availableBytes
    }

    fun hasNetwork(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun isMetered(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.isActiveNetworkMetered
    }
}
