package dev.archdroid.terminal

import dev.archdroid.terminal.env.Downloader
import dev.archdroid.terminal.env.PacmanConf
import dev.archdroid.terminal.env.RootfsExtractor
import dev.archdroid.terminal.env.formatBytes
import dev.archdroid.terminal.files.VirtualFs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File

class PureLogicTest {
    @Test fun parseMd5_standardLine() {
        val md5 = "d41d8cd98f00b204e9800998ecf8427e"
        assertEquals(md5, Downloader.parseMd5("$md5  ArchLinuxARM-aarch64-latest.tar.gz\n", "ArchLinuxARM-aarch64-latest.tar.gz"))
    }

    @Test fun parseMd5_rejectsGarbage() {
        assertNull(Downloader.parseMd5("<html>Not found</html>", "x.tar.gz"))
    }

    @Test fun pacmanConf_patchIsIdempotent() {
        val src = "[options]\nHoldPkg = pacman glibc\nCheckSpace\n[core]\nInclude = /etc/pacman.d/mirrorlist\n"
        val once = PacmanConf.patch(src)
        assertTrue(once.contains("#CheckSpace"))
        assertTrue(once.lines().contains("DisableSandbox"))
        assertEquals(once, PacmanConf.patch(once))
    }

    @Test fun resolveEntry_blocksTraversal() {
        val root = File("/tmp/root")
        assertEquals(File(root, "usr/bin/bash"), RootfsExtractor.resolveEntry(root, "./usr/bin/bash"))
        assertNull(RootfsExtractor.resolveEntry(root, "./"))
        try { RootfsExtractor.resolveEntry(root, "../etc/passwd"); fail("expected IOException") } catch (_: java.io.IOException) {}
    }

    @Test fun virtualFs_normalize() {
        val fs = VirtualFs(File("/tmp/root"))
        assertEquals("/a/c", fs.normalize("/a/b/../c"))
        assertEquals("/", fs.normalize("/.."))
    }

    @Test fun formatBytes_units() {
        assertEquals("512 B", formatBytes(512))
        assertEquals("1.5 MB", formatBytes(1_572_864))
    }
}
